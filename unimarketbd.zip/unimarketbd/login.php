<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="./assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/css/shared/main.css">
  <!-- User -->
  <link rel="stylesheet" href="./assets/css/user/header.css">
  <link rel="stylesheet" href="./assets/css/user/login.css">
  <title>UnimarketBd | Login</title>
</head>
<body>
  <?php
    session_start();

    include_once './config/Constants.php';
    include_once './config/Database.php';
    include_once './models/user/Users.php';
    include_once './partials/user/login-with-cookie.php';
    include_once './partials/user/wishlist-modal.php';
    include_once './partials/user/cart-modal.php';
    include_once './partials/user/orders-modal.php';
    include_once './partials/user/header.php';
    include_once './partials/user/get-wishlist-count.php';
    include_once './partials/user/get-cart-count.php';
    include_once './partials/user/get-orders-count.php';
    include_once './partials/user/footer.php';
  ?>

  <?php
    loginWithCookie();

    if(isset($_SESSION['userLoginDetails'])) header('location: '.SITE_URL);
  ?>

  <?php echo wishlistModal(); ?> <!-- Render wishlist modal -->
  <?php echo cartModal(); ?> <!-- Render cart modal -->
  <?php echo ordersModal(); ?> <!-- Render orders modal -->

  <?php echo headerHTML(); ?>  
  <section class="login-register-section">
    <div class="container">
      <div class="mb-5 text-center login-register-choose-container">
        <span onclick="toggleLoginRegisterForm()" class="login-choose-text text-primary" id="login-choose-text">Login</span>
        <span class="mx-2 vertical-separator">|</span>
        <span onclick="toggleLoginRegisterForm()" class="register-choose-text" id="register-choose-text">Register</span>
      </div>

      <form onsubmit="login(event)" class="bg-white rounded mx-auto p-5 login-form" id="login-form">
        <div class="form-group">
          <label for="login-username-email">Username / E-mail</label>
          <input required type="text" class="shadow-none form-control login-username-email" id="login-username-email">
        </div>
        <div class="form-group">
          <label for="login-password">Password</label>
          <input required type="password" class="shadow-none form-control login-password" id="login-password">
        </div>
        <div class="d-flex justify-content-between">
          <div class="remember-me-container">
            <input type="checkbox" name="remember-me" id="remember-me">
            <label for="remember-me">Remember Me</label>
          </div>
          <a href="./forgot-password.php" class="forgot-password-text">Forgot Password?</a>
        </div>
        <button class="mt-3 shadow-none btn btn-primary login-btn" id="login-btn">Login</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
        <span class="d-block text-center mt-4 no-account-text">
          Don't have account yet? <span onclick="toggleLoginRegisterForm()" class="text-primary register-text">Register</span> now!
        </span>
      </form>

      <form onsubmit="register(event)" class="bg-white rounded mx-auto d-none p-5 register-form" id="register-form">
        <div class="form-group">
          <label for="register-username">First Name</label>
          <input required minlength="3" maxlength="12" match="" type="text" class="shadow-none form-control" id="register-username">
        </div>
  <div class="form-group">
          <label for="register-username">Last Name</label>
          <input required minlength="3" maxlength="12" match="" type="text" class="shadow-none form-control" id="register-username">
        </div>
        <div class="form-group">
          <label for="register-username">Username</label>
          <input required minlength="3" maxlength="12" match="" type="text" class="shadow-none form-control" id="register-username">
        </div>
        <div class="form-group">
          <label for="register-email">Email</label>
          <input required type="email" class="shadow-none form-control" id="register-email">
        </div>
        <div class="form-group">
          <label for="register-password-new">New Password</label>
          <input required minlength="8" maxlength="20" type="password" class="shadow-none form-control register-password-new" id="register-password-new">
        </div>
        <div class="form-group">
          <label for="register-password-confirm">Confirm Password</label>
          <input required minlength="8" maxlength="20" type="password" class="shadow-none form-control register-password-confirm" id="register-password-confirm">
        </div>
        <button class="mt-3 shadow-none btn btn-primary register-btn" id="register-btn">Register</button>
        <div class="d-none mt-4 text-center res-msg-container">
          <!-- response goes here -->
        </div>
        <span class="d-block text-center mt-4 already-registered-text">
          Already Registered? <span onclick="toggleLoginRegisterForm()" class="text-primary login-text">Login</span> now!
        </span>
      </form> 
    </div>
  </section>

  <?php echo footer(); ?> <!-- Render footer -->

  <!-- Shared -->
  <script src="./assets/js/shared/font-awesome.min.js"></script>
  <script src="./assets/js/shared/jquery.min.js"></script>
  <script src="./assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="./assets/js/shared/main.js"></script>
  <!-- User -->
  <script src="./assets/js/user/login.js"></script>
</body>
</html>