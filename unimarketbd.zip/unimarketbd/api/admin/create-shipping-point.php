<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/ShippingPoints.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->name) || !isset($data->location) || !isset($data->description) || !isset($_SESSION['adminLoginDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->name = trim($data->name);
  $data->location = trim($data->location);
  $data->description = trim($data->description);

  $curErrs = [];

  // error handling
  $customErrors = new CustomErrors('Name', $data->name, 1, 30, null, null, null, null, null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  $customErrors = new CustomErrors('Location', $data->location, 1, 40, null, null, null, null, null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  $customErrors = new CustomErrors('Description', $data->description, 1, 500, null, null, null, null, null, $curErrs);
  $curErrs = $customErrors->concatErrs();

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate ShippingPoints object
  $shippingPoints = new ShippingPoints($db);

  // set properties
  $shippingPoints->name = $data->name;
  $shippingPoints->location = $data->location;
  $shippingPoints->description = $data->description;

  // creating the shipping point
  $isCreated = $shippingPoints->create();
  
  if(!$isCreated) {
    // exit if shipping point is not created
    http_response_code(503);
    echo json_encode(['message' => 'Failed creating the shipping point']);
    exit();
  }

  http_response_code(201);
  echo json_encode(['redirectURL' => './shipping-points.php?p=1']);
?>