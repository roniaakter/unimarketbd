<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: DELETE');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Products.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->id) || !isset($_SESSION['adminLoginDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->id = trim($data->id);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Products object
  $products = new Products($db);

  // set properties
  $products->id = $data->id;

  // deleting the product
  $isDeleted = $products->delete();
  
  if(!$isDeleted) {
    // exit if product is not deleted
    http_response_code(503);
    echo json_encode(['message' => 'Failed deleting the product']);
    exit();
  }

  unlink(glob("../../assets/img/shared/products/".$products->id.".*")[0]);

  http_response_code(200);
  echo json_encode(['redirectURL' => './products.php?p=1']);
?>