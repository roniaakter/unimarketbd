<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: DELETE');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/ShippingPoints.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->id) || !isset($_SESSION['adminLoginDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->id = trim($data->id);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate ShippingPoints object
  $shippingPoints = new ShippingPoints($db);

  // set properties
  $shippingPoints->id = $data->id;

  // deleting the shipping point
  $isDeleted = $shippingPoints->delete();
  
  if(!$isDeleted) {
    // exit if shipping point is not deleted
    http_response_code(503);
    echo json_encode(['message' => 'Failed deleting the shipping point']);
    exit();
  }

  http_response_code(200);
  echo json_encode(['redirectURL' => './shipping-points.php?p=1']);
?>