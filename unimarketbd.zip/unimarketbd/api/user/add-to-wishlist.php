<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Products.php';
  include_once '../../models/user/Wishlist.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // redirect to login page if not authenticated
  if(!isset($_SESSION['userLoginDetails']['id'])) {
    http_response_code(400);
    echo json_encode(['redirectURL' => SITE_URL.'/login.php']);
    exit(); 
  }

  // exit if all fields are not passed
  if(!isset($data->productId)) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->productId = trim($data->productId);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Products object
  $products = new Products($db);

  // set properties
  $products->id = $data->productId;

  // fetching the product info
  $stmt = $products->readById();
  $rowCount = $stmt->rowCount();
  
  if(!$rowCount) {
    // exit if product is not found
    http_response_code(404);
    echo json_encode(['message' => 'Invalid product id']);
    exit();
  }

  // instantiate Wishlist object
  $wishlist = new Wishlist($db);

  // set properties
  $wishlist->productId = $data->productId;
  $wishlist->userId = $_SESSION['userLoginDetails']['id'];
  
  // read an entry with same info
  $stmt = $wishlist->readSingle();
  $rowCount = $stmt->rowCount();

  if($rowCount) {
    // exit if product already added to wishlist
    http_response_code(400);
    echo json_encode(['message' => 'Product already exists into wishlist']);
    exit();
  }

  // otherwise, add the product to wishlist
  $isCreated = $wishlist->create();

  if(!$isCreated) {
    // exit if "add to wishlist" failed
    http_response_code(503);
    echo json_encode(['message' => 'Failed adding product into wishlist']);
    exit();
  }

  // get the product info
  $stmt = $products->readById();
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  $row['imgURL'] = glob("../../assets/img/shared/products/".$row['id'].".*")[0];

  http_response_code(201);
  echo json_encode(['product' => $row]);
?>