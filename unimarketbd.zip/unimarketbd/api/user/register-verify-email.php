<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../models/shared/CustomErrors.php';
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/user/Users.php';

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  session_start();

  define('VF_CODE_EXPIRED_MAX_TIME', 15 * 60);

  // exit if all fields are not passed
  if(!isset($data->verificationCode) || !isset($_SESSION['userRegistrationDetails'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->verificationCode = trim($data->verificationCode);

  $curErrs = [];

  // error handling
  if(time() - $_SESSION['userRegistrationDetails']['verificationCodeSent'] > constant('VF_CODE_EXPIRED_MAX_TIME')) {
    $curErrs[] = 'Verification code expired';
  }

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // instantiate Users object
  $users = new Users($db);

  // set properties
  $users->username = $_SESSION['userRegistrationDetails']['username'];
  $users->email = $_SESSION['userRegistrationDetails']['email'];

  // check for username availability
  if($users->readByUsername()->rowCount()) {
    $curErrs[] = 'Username already used';
  }

  // check for email availability
  if($users->readByEmail()->rowCount()) {
    $curErrs[] = 'Email already used';
  }

  if($data->verificationCode != $_SESSION['userRegistrationDetails']['verificationCode']) {
    $curErrs[] = 'Invalid verification code';
  }

  // exit if errors found
  if(count($curErrs)) {
    http_response_code(400);
    echo json_encode(['message' => $curErrs[0]]);
    exit();
  }

  // set properties
  $users->password = $_SESSION['userRegistrationDetails']['password'];

  // create the user
  if(!$users->create()) {
    http_response_code(503);
    echo json_encode(['message' => 'Error occured creating the user']);
    exit();
  }

  unset($_SESSION['userRegistrationDetails']);

  http_response_code(201);
  echo json_encode(['redirectURL' => SITE_URL.'/login.php']);
?>