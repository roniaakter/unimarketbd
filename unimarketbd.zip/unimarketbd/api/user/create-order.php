<?php
  // essential headers
  header('Access-Control-Allow-Origin: *');
  header('Content-Type: application/json; charset=UTF-8');
  header('Access-Control-Allow-Methods: POST');
  header('Access-Control-Max-Age: 3600');
  header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

  // essential files
  include_once '../../config/Constants.php';
  include_once '../../config/TimeZone.php';
  include_once '../../config/Database.php';
  include_once '../../models/admin/Products.php';
  include_once '../../models/user/Cart.php';
  include_once '../../models/admin/ShippingPoints.php';
  include_once '../../models/user/Orders.php';
  include_once '../../models/user/OrderStatusesHistory.php';
  include_once '../../models/user/OrderContains.php';

  session_start();

  // get raw pasted data
  $data = json_decode(file_get_contents("php://input"));

  // exit if all fields are not passed
  if(!isset($data->shippingPointId) || !isset($data->paymentMethodId) || !isset($data->userLocation) || !isset($data->phoneNum) || !isset($_SESSION['userLoginDetails']['id']) || !isset($_SESSION['userLoginDetails']['orderId'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Something Went Wrong']);
    exit();
  }

  // trimming the fields
  $data->shippingPointId = trim($data->shippingPointId);
  $data->paymentMethodId = trim($data->paymentMethodId) == '' ? null : trim($data->paymentMethodId);
  $data->userLocation = trim($data->userLocation);
  $data->phoneNum = trim($data->phoneNum);

  // instantiate db & connect
  $database = new Database();
  $db = $database->connect();

  // i) instantiate ShippingPoints object
  $shippingPoints = new ShippingPoints($db);

  // set properties
  $shippingPoints->id = $data->shippingPointId;

  // fetching the availability of the shipping point
  $stmt = $shippingPoints->readById();
  $rowCount = $stmt->rowCount();
  
  if(!$rowCount) {
    // exit if no product is found for this order
    http_response_code(404);
    echo json_encode(['message' => 'Invalid Shipping Point']);
    exit();
  }

  // ii) instantiate Cart object
  $cart = new Cart($db);

  // set properties
  $cart->orderId = $_SESSION['userLoginDetails']['orderId'];

  // fetching the number of items for the order
  $stmt = $cart->readByOrderId();
  $rowCount = $stmt->rowCount();
  
  if(!$rowCount) {
    // exit if no product is found for this order
    http_response_code(404);
    echo json_encode(['message' => 'No items added for the cart yet']);
    exit();
  }

  // iii) instantiate Orders object
  $orders = new Orders($db);

  // set properties
  $orders->id = $_SESSION['userLoginDetails']['orderId'];
  $orders->shippingPointId = $data->shippingPointId;
  $orders->paymentMethodId = $data->paymentMethodId;
  $orders->userLocation = $data->userLocation;
  $orders->phoneNum = $data->phoneNum;

  // update shipping point for the order
  $isUpdated = $orders->update();

  if(!$isUpdated) {
    // exit if no product is found for this order
    http_response_code(404);
    echo json_encode(['message' => 'No items added for the cart yet']);
    exit();
  }

  // iv) instantiate OrderStatusesHistory object
  $orderStatusesHistory = new OrderStatusesHistory($db);

  // set properties
  $orderStatusesHistory->orderId = $_SESSION['userLoginDetails']['orderId'];
  $orderStatusesHistory->status = 'Pending';
  
  // create new status into order statuses history
  $orderStatusesHistory->create();

  // v) instantiate Orders object
  $orders = new Orders($db);

  // set properties
  $orders->userId = $_SESSION['userLoginDetails']['id'];
  
  // create new order
  $orders->create();

  $newOrderId = $db->lastInsertId();

  // vi) instantiate OrderStatusesHistory object
  $orderStatusesHistory = new OrderStatusesHistory($db);

  // set properties
  $orderStatusesHistory->orderId = $newOrderId;
  $orderStatusesHistory->status = 'Instantiated';
  
  // create new order
  $orderStatusesHistory->create();

  // vii) instantiate Orders object
  $cart = new Cart($db);

  // set properties
  $cart->orderId = $_SESSION['userLoginDetails']['orderId'];

  // fetching the number of items for the order
  $stmt = $cart->readByOrderIdWithProducts();
  $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

  foreach ($result as $row) {
    extract($row);

    if($stockUnits < $quantity) {
      // exit if no product is found for this order
      http_response_code(400);
      echo json_encode(['message' => 'Sorry! Stocks exceeded for ' . $name]);
      exit();
    }
  }

  foreach($result as $row) {
    extract($row);

    // instantiate OrderContains object
    $orderContains = new OrderContains($db);

    // set properties
    $orderContains->orderId = $_SESSION['userLoginDetails']['orderId'];
    $orderContains->productId = $id;
    $orderContains->productName = $name;
    $orderContains->productCategoryName = $categoryName;
    $orderContains->productCompanyName = $companyName;
    $orderContains->productUnitPrice = $unitPrice;
    $orderContains->productShippingCost = $shippingCost;
    $orderContains->productQuantity = $quantity;
    $orderContains->productDescription = $description;

    $orderContains->create();

    // lessen stocks
    $products = new Products($db);

    $products->id = $id;
    $products->stockUnits = $stockUnits - $quantity;
    $products->updateStockUnitsById();
  }

  // vii) instantiate OrderContains object
  $orderContains = new OrderContains($db);

  // set properties
  $orderContains->orderId = $_SESSION['userLoginDetails']['orderId'];

  // read products of an order
  $stmt = $orderContains->readByOrderId();
  $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

  $_SESSION['userLoginDetails']['orderId'] = $newOrderId;
  
  http_response_code(200);
  echo json_encode(['redirectURL' => SITE_URL]);
?>