<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/sidebar.css">
  <link rel="stylesheet" href="../assets/css/admin/nav.css">
  <link rel="stylesheet" href="../assets/css/admin/products.css">
  <title>UnimarketBd Admin | Products</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/TimeZone.php';
    include_once '../config/Database.php';
    include_once '../models/admin/Admins.php';
    include_once '../models/admin/Categories.php';
    include_once '../models/admin/Companies.php';
    include_once '../models/admin/Products.php';
    include_once '../partials/admin/login-with-cookie.php';
    include_once '../partials/admin/sidebar.php';
    include_once '../partials/admin/nav.php';
    include_once '../partials/admin/get-categories-for-products.php';
    include_once '../partials/admin/get-companies-for-products.php';
    include_once '../partials/admin/get-page-count-products.php';
    include_once '../partials/admin/get-by-page-products.php';
    include_once '../partials/admin/get-farthest-page-no.php';
  ?>

  <?php
    loginWithCookie();

    if(!isset($_SESSION['adminLoginDetails'])) header('location: ./login.php');
  ?>

  <?php
    if(!isset($_GET['p'])) header('location: ./products.php?p=1');

    $curPageNo = (int) $_GET['p'];

    $maxPages = getPageCountProducts();

    if(($curPageNo != 1) && ($curPageNo < 1 || $curPageNo > $maxPages)) header('location: ./products.php?p=1');

    $products = getByPageProducts($curPageNo);

    $lefMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['leftMost'];
    $rightMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['rightMost'];
  ?>

  <?php echo sideBarHTML(); ?>
  <?php echo navHTML(); ?>

  <main class="p-4 main products-main">
    <div class="mb-4 d-flex align-items-center justify-content-between create-product-modal-openup-container">
      <h1 class="mb-0 text-dark page-title products-title">Products</h1>
      <button class="btn btn-primary shadow-none create-product-modal-openup-btn" data-toggle="modal" data-target="#create-product-modal">Add a Product</button>
    </div>

    <!-- Table -->
    <table class="bg-white table table-bordered">
      <thead>
        <tr class="border-bottom-0">
          <th class="border-bottom-0 id">ID</th>
          <th class="border-bottom-0 name">Name</th>
          <th class="border-bottom-0 category">Category</th>
          <th class="border-bottom-0 company">Company</th>
          <th class="border-bottom-0 unit-price">Unit Price</th>
          <th class="border-bottom-0 shipping-cost">Shipping Cost</th>
          <th class="border-bottom-0 stock-units">Available Stocks</th>
          <th class="border-bottom-0 created-at">Created At</th>
          <th class="border-bottom-0 actions">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          if(!$products) {
            echo 
            "<tr>
              <td class='text-center' colspan='7'>No Products found</td>
            </tr>";
          } else {
            foreach ($products as $product) {
              extract($product);

              $createdAt = date('F j, Y', strtotime($createdAt));

              echo 
              "<tr>
                <td class='border-bottom-0 id'>$id</td>
                <td class='border-bottom-0 name'>$productName</td>
                <td class='border-bottom-0 category' data-category-id='$categoryId'>$categoryName</td>
                <td class='border-bottom-0 company' data-company-id='$companyId'>$companyName</td>
                <td class='border-bottom-0 unit-price' data-unit-price='$unitPrice'>$unitPrice TK</td>
                <td class='border-bottom-0 shipping-cost' data-shipping-cost='$shippingCost'>$shippingCost TK</td>
                <td class='border-bottom-0 stock-units'>$stockUnits</td>
                <td class='border-bottom-0 description d-none'>$description</td>
                <td class='border-bottom-0 created-at'>$createdAt</td>
                <td class='border-bottom-0 actions'>
                  <button class='btn btn-sm btn-info shadow-none' onclick='editProductPre(event)' data-toggle='modal' data-target='#edit-product-modal' data-product-id='$id'>
                    <i class='fas fa-edit'></i>
                  </button>
                  <button class='btn btn-sm btn-danger shadow-none' onclick='deleteProductPre(event)' data-toggle='modal' data-target='#delete-product-modal' data-product-id='$id'>
                    <i class='fas fa-trash'></i>
                  </button>
                </td>
              </tr>";
            }
          }
        ?>
      </tbody>
    </table>
    <!-- Pagination -->
    <ul class="mt-4 pagination justify-content-center">
      <?php
        if($products) {
          if($curPageNo - 1 > 0) {
            $pageNo = $curPageNo - 1;
            echo "<li class='page-item'><a class='page-link' href='./products.php?p=$pageNo'>Previous</a></li>";
          }
  
          for($pageNo = $lefMostPageInPagination; $pageNo <= $rightMostPageInPagination; $pageNo++) {
            $activeClass = ($pageNo == $curPageNo) ? 'active': '';
            echo "<li class='page-item $activeClass'><a class='page-link' href='./products.php?p=$pageNo'>$pageNo</a></li>";
          }
  
          if($curPageNo + 1 <= $maxPages) {
            $pageNo = $curPageNo + 1;
            echo "<li class='page-item'><a class='page-link' href='./products.php?p=$pageNo'>Next</a></li>";
          }
        }
      ?>
    </ul>

    <!-- Create Product Modal -->
    <div class="modal fade" id="create-product-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-primary text-center modal-heading">Add a Product</h3>
          <form onsubmit="createProduct(event)" class="create-product-form" id="create-product-form">
            <div class="form-group">
              <label for="create-product-name">Name</label>
              <input required minlength="1" maxlength="30" type="text" class="shadow-none form-control create-product-name" id="create-product-name">
            </div>
            <div class="form-group">
              <label for="create-product-company">Category</label>
              <select class="shadow-none form-control create-product-category" id="create-product-category">
                <option value="">-- Select a Category --</option>
                <?php
                  if(getCategoriesForProducts()) {
                    foreach (getCategoriesForProducts() as $category) {
                      extract($category);
                      echo "<option value='$id'>$name</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label for="create-product-company">Company</label>
              <select class="shadow-none form-control create-product-company" id="create-product-company">
                <option value="">-- Select a Company --</option>
                <?php
                  if(getCompaniesForProducts()) {
                    foreach (getCompaniesForProducts() as $company) {
                      extract($company);
                      echo "<option value='$id'>$name</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <div class="d-flex price-cost-container">
              <div class="form-group">
                <label for="create-product-unit-price">Unit Price</label>
                <input required type="number" min="0" step="0.01" class="shadow-none form-control create-product-unit-price" id="create-product-unit-price">
              </div>
              <div class="ml-2 form-group">
                <label for="create-product-shipping-cost">Shipping Cost</label>
                <input required type="number" min="0" step="0.01" class="shadow-none form-control create-product-shipping-cost" id="create-product-shipping-cost">
              </div>
            </div>
            <div class="form-group">
              <label for="create-product-img">Image</label>
              <input required type="file" class="shadow-none form-control create-product-img" id="create-product-img">
            </div>
            <div class="form-group">
              <label for="create-product-desc">Description</label>
              <textarea required minlength="1" maxlength="500" type="text" class="shadow-none form-control create-product-desc" id="create-product-desc"></textarea>
            </div>
            <div class="form-group">
              <label for="create-product-stock-units">Stock Units</label>
              <input required type="number" min="0" class="shadow-none form-control create-product-stock-units" id="create-product-stock-units">
            </div>
            <button class="mt-3 btn btn-primary shadow-none create-product-btn" id="create-product-btn">Add</button>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Edit Product Modal -->
    <div class="modal fade" id="edit-product-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-primary text-center modal-heading">Edit Product</h3>
          <form onsubmit="editProduct(event)" class="edit-product-form" id="edit-product-form">
            <input type="hidden" name="edit-product-id" id="edit-product-id"/>     
            <div class="form-group">
              <label for="edit-product-name">Name</label>
              <input required minlength="1" maxlength="30" type="text" class="shadow-none form-control edit-product-name" id="edit-product-name">
            </div>
            <div class="form-group">
              <label for="edit-product-company">Category</label>
              <select class="shadow-none form-control edit-product-category" id="edit-product-category">
                <option value="">-- Select a Category --</option>
                <?php
                  if(getCategoriesForProducts()) {
                    foreach (getCategoriesForProducts() as $category) {
                      extract($category);
                      echo "<option value='$id'>$name</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label for="edit-product-company">Company</label>
              <select class="shadow-none form-control edit-product-company" id="edit-product-company">
                <option value="">-- Select a Company --</option>
                <?php
                  if(getCompaniesForProducts()) {
                    foreach (getCompaniesForProducts() as $company) {
                      extract($company);
                      echo "<option value='$id'>$name</option>";
                    }
                  }
                ?>
              </select>
            </div>
            <div class="d-flex price-cost-container">
              <div class="form-group">
                <label for="edit-product-unit-price">Unit Price</label>
                <input required type="number" min="0" step="0.01" class="shadow-none form-control edit-product-unit-price" id="edit-product-unit-price">
              </div>
              <div class="ml-2 form-group">
                <label for="edit-product-shipping-cost">Shipping Cost</label>
                <input required type="number" min="0" step="0.01" class="shadow-none form-control edit-product-shipping-cost" id="edit-product-shipping-cost">
              </div>
            </div>
            <div class="form-group">
              <label for="edit-product-img">Image</label>
              <input type="file" class="shadow-none form-control edit-product-img" id="edit-product-img">
            </div>
            <div class="form-group">
              <label for="edit-product-desc">Description</label>
              <textarea required minlength="1" maxlength="500" type="text" class="shadow-none form-control edit-product-desc" id="edit-product-desc"></textarea>
            </div>
            <div class="form-group">
              <label for="edit-product-stock-units">Stock Units</label>
              <input required type="number" min="0" class="shadow-none form-control edit-product-stock-units" id="edit-product-stock-units">
            </div>
            <button class="mt-3 btn btn-primary shadow-none edit-product-btn" id="create-product-btn">Edit</button>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Delete Product Modal -->
    <div class="modal fade" id="delete-product-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-danger text-center modal-heading">You sure deleting this product?</h3>
          <form onsubmit="deleteProduct(event)" class="delete-product-form" id="delete-product-form" data-product-id="">
            <div class="text-center delete-product-btn-container">
              <button class="btn btn-danger shadow-none delete-product-btn" id="delete-product-btn">Delete</button>
            </div>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/products.js"></script>
  <script src="../assets/js/admin/logout.js"></script>
</body>
</html>