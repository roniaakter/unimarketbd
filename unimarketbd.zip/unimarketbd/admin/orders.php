<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/sidebar.css">
  <link rel="stylesheet" href="../assets/css/admin/nav.css">
  <link rel="stylesheet" href="../assets/css/admin/orders.css">
  <title>UnimarketBd Admin | Orders</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/TimeZone.php';
    include_once '../config/Database.php';
    include_once '../models/user/Orders.php';
    include_once '../models/user/OrderStatusesHistory.php';
    include_once '../models/user/OrderContains.php';
    include_once '../partials/admin/login-with-cookie.php';
    include_once '../partials/admin/sidebar.php';
    include_once '../partials/admin/nav.php';
    include_once '../partials/admin/get-page-count-orders.php';
    include_once '../partials/admin/get-by-page-orders.php';
    include_once '../partials/admin/get-farthest-page-no.php';
    include_once '../partials/admin/get-basic-info-of-order.php';
    include_once '../partials/admin/get-status-history-of-order.php';
    include_once '../partials/admin/get-product-items-of-order.php';
    include_once '../partials/admin/get-total-cost-of-order.php';
  ?>

  <?php
    loginWithCookie();

    if(!isset($_SESSION['adminLoginDetails'])) header('location: ./login.php');
  ?>

  <?php
    if(!isset($_GET['p'])) header('location: ./orders.php?p=1');

    $curPageNo = (int) $_GET['p'];

    $maxPages = getPageCountOrders();

    if(($curPageNo != 1) && ($curPageNo < 1 || $curPageNo > $maxPages)) header('location: ./orders.php?p=1');

    $orders = getByPageOrders($curPageNo);

    $lefMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['leftMost'];
    $rightMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['rightMost'];
  ?>

  <?php echo sideBarHTML(); ?>
  <?php echo navHTML(); ?>

  <main class="p-4 main orders-main">
    <div class="mb-4">
      <h1 class="mb-0 text-dark page-title orders-title">Orders</h1>
    </div>

    <div class="order-items">
      <?php
        if($orders) {
          foreach ($orders as $order) {
            extract($order);
            
            $orderItem = "<div class='order-item bg-white p-4 border'>";
              $orderItem .= 
              "<div class='mb-4 d-flex flex-column align-items-center order-item-basic-info'>
                <span class='order-item-id'>
                  Order ID: <span class='text-primary'>#".$orderId."</span>
                </span>
                <span class='my-2 p-2 border d-flex flex-column align-items-center order-item-user-info'>
                  <span class='text-primary order-item-user-username'>".getBasicInfoOfOrder($orderId)['username']."</span>
                  <span class='text-primary order-item-user-email'>".getBasicInfoOfOrder($orderId)['email']."</span>
                </span>
                <span class='order-item-shipping-point'>
                  Shipping Point: <span class='text-primary order-item-user-username'>".getBasicInfoOfOrder($orderId)['shippingPointName']."</span>
                </span>
                <span class='order-item-user-location'>
                  User's location: <span class='text-primary order-item-user-username'>".getBasicInfoOfOrder($orderId)['userLocation']."</span>
                </span>
                <span class='order-item-shipping-point'>
                  Phone: <span class='text-primary order-item-user-username'>".getBasicInfoOfOrder($orderId)['phoneNum']."</span>
                </span>
              </div>";

              $orderItem .=
              "<div class='mb-4 text-center dropdown order-item-status-history'>
                <button class='btn border shadow-none dropdown-toggle' type='button' id='orderStatusesHistoryDropdown' data-toggle='dropdown'>
                  Status History
                </button>
                <div class='dropdown-menu'>";
            
              $allPossibleStatuses = ['Pending', 'Accepted', 'Sent', 'Received', 'Cancelled', 'Returned'];
              $maxStatusIdx = 0;

              foreach (getStatusHistoryOfOrder($orderId) as $statusHistory) {
                $statusHistory['changedAt'] = date("F j, Y, g:i a", strtotime($statusHistory['changedAt']));
          
                $orderItem .= 
                "<span class='d-flex align-items-center dropdown-item'>
                  ".$statusHistory['status']." 
                  <span class='mx-2'>-</span>
                  ".$statusHistory['changedAt']."
                </span>";

                $maxStatusIdx = max($maxStatusIdx, array_search($statusHistory['status'], array_values($allPossibleStatuses)));
              }

              if($maxStatusIdx < 3) {
                $orderItem .= 
                "<span data-order-id='$orderId' data-order-status='".$allPossibleStatuses[$maxStatusIdx + 1]."' onclick='changeOrderStatus(event)' class='d-flex justify-content-center dropdown-item'>
                  ".$allPossibleStatuses[$maxStatusIdx + 1]."?
                </span>";

                $orderItem .= 
                "<span data-order-id='$orderId' data-order-status='Cancelled' onclick='changeOrderStatus(event)' class='d-flex justify-content-center dropdown-item'>
                  Cancelled?
                </span>";
              }
          
              $orderItem .=
                "</div>
              </div>";

              $orderItem .=
              "<ul class='mb-4 w-50 mx-auto list-unstyled mb-0 order-item-products'>";

              foreach (getProductItemsOfOrder($orderId) as $productItemOfOrder) {
                $imgURL = glob("../assets/img/shared/products/".$productItemOfOrder['productId'].".*")[0];

                $orderItem .= 
                "<li class='d-flex align-items-center order-item-product'>
                  <img width='60' src='$imgURL' class='order-item-product-img'/>
                  <span class='ml-4 order-item-product-quantity'>".$productItemOfOrder['productQuantity']."</span>
                  <span class='ml-4 order-item-multiply-icon'>x</span>
                  <div class='ml-4 d-flex flex-column order-item-product-info'>
                    <span class='text-primary order-item-product-name'>".$productItemOfOrder['productName']."</span>
                    <span class='order-item-category-name'>
                      From <span class='text-primary'>".$productItemOfOrder['productCategoryName']."</span>
                    </span>
                    <span class='order-item-company-name'>
                      By <span class='text-primary'>".$productItemOfOrder['productCompanyName']."</span>
                    </span>
                    <span class='order-item-product-price-cost'>
                      ".$productItemOfOrder['productUnitPrice']." TK (+".$productItemOfOrder['productShippingCost']." TK)
                    </span>
                  </div>
                  <span class='ml-4 order-item-equal-icon'>=</span>
                  <span class='ml-4 order-item-individual-total'>".number_format(($productItemOfOrder['productUnitPrice'] * $productItemOfOrder['productQuantity']) + $productItemOfOrder['productShippingCost'], 2)." TK</span>
                </li>";
              }

              $orderItem .=
              "</ul>";

              $orderItem .= 
              "<div class='text-center total-order-cost-container'>
                <span class='total-order-cost'>
                  Total: ".getTotalCostOfOrder($orderId)." TK
                </span>
              </div>";


            $orderItem .= "</div>";

            echo $orderItem;
          }
        }
      ?>
    </div>

    <!-- Pagination -->
    <ul class="mt-4 pagination justify-content-center">
      <?php
        if($orders) {
          if($curPageNo - 1 > 0) {
            $pageNo = $curPageNo - 1;
            echo "<li class='page-item'><a class='page-link' href='./orders.php?p=$pageNo'>Previous</a></li>";
          }
  
          for($pageNo = $lefMostPageInPagination; $pageNo <= $rightMostPageInPagination; $pageNo++) {
            $activeClass = ($pageNo == $curPageNo) ? 'active': '';
            echo "<li class='page-item $activeClass'><a class='page-link' href='./orders.php?p=$pageNo'>$pageNo</a></li>";
          }
  
          if($curPageNo + 1 <= $maxPages) {
            $pageNo = $curPageNo + 1;
            echo "<li class='page-item'><a class='page-link' href='./orders.php?p=$pageNo'>Next</a></li>";
          }
        }
      ?>
    </ul>
  </main>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/orders.js"></script>
  <script src="../assets/js/admin/logout.js"></script>
</body>
</html>