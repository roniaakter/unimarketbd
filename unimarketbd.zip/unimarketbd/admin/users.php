<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Shared -->
  <link rel="stylesheet" href="../assets/css/shared/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/css/shared/main.css">
  <!-- Admin -->
  <link rel="stylesheet" href="../assets/css/admin/sidebar.css">
  <link rel="stylesheet" href="../assets/css/admin/nav.css">
  <link rel="stylesheet" href="../assets/css/admin/users.css">
  <title>UnimarketBd Admin | Users</title>
</head>
<body>
  <?php
    session_start();

    include_once '../config/Constants.php';
    include_once '../config/Database.php';
    include_once '../models/admin/Admins.php';
    include_once '../models/user/Users.php';
    include_once '../partials/admin/sidebar.php';
    include_once '../partials/admin/nav.php';
    include_once '../partials/admin/login-with-cookie.php';
    include_once '../partials/admin/get-page-count-users.php';
    include_once '../partials/admin/get-by-page-users.php';
    include_once '../partials/admin/get-farthest-page-no.php';
  ?>

  <?php
    loginWithCookie();

    if(!isset($_SESSION['adminLoginDetails'])) header('location: ./login.php');
  ?>

  <?php
    if(!isset($_GET['p'])) header('location: ./users.php?p=1');

    $curPageNo = (int) $_GET['p'];

    $maxPages = getPageCountUsers();

    if(($curPageNo != 1) && ($curPageNo < 1 || $curPageNo > $maxPages)) header('location: ./users.php?p=1');

    $users = getByPageUsers($curPageNo);

    $lefMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['leftMost'];
    $rightMostPageInPagination = getFarthestPageNo($maxPages, $curPageNo)['rightMost'];
  ?>

  <?php echo sideBarHTML(); ?>
  <?php echo navHTML(); ?>

  <main class="p-4 main users-main">
    <div class="mb-4 users-header">
      <h1 class="mb-0 text-dark page-title users-title">Users</h1>
    </div>
    
    <!-- Table -->
    <table class="bg-white table table-bordered">
      <thead>
        <tr class="border-bottom-0">
          <th class="border-bottom-0 id">ID</th>
          <th class="border-bottom-0 username">Username</th>
          <th class="border-bottom-0 email">Email</th>
          <th class="border-bottom-0 added-at">Added At</th>
        </tr>
      </thead>
      <tbody>
        <?php 
          if(!$users) {
            echo 
            "<tr>
              <td class='text-center' colspan='4'>No users found</td>
            </tr>";
          } else {
            foreach ($users as $user) {
              extract($user);

              $createdAt = date('F j, Y', strtotime($createdAt));

              echo 
              "<tr>
                <td class='border-bottom-0 id'>$id</td>
                <td class='border-bottom-0 name'>$username</td>
                <td class='border-bottom-0 email'>$email</td>
                <td class='border-bottom-0 added-at'>$createdAt</td>
              </tr>";
            }
          }
        ?>
      </tbody>
    </table>
    <!-- Pagination -->
    <ul class="mt-4 pagination justify-content-center">
      <?php
        if($users) {
          if($curPageNo - 1 > 0) {
            $pageNo = $curPageNo - 1;
            echo "<li class='page-item'><a class='page-link' href='./users.php?p=$pageNo'>Previous</a></li>";
          }
  
          for($pageNo = $lefMostPageInPagination; $pageNo <= $rightMostPageInPagination; $pageNo++) {
            $activeClass = ($pageNo == $curPageNo) ? 'active': '';
            echo "<li class='page-item $activeClass'><a class='page-link' href='./users.php?p=$pageNo'>$pageNo</a></li>";
          }
  
          if($curPageNo + 1 <= $maxPages) {
            $pageNo = $curPageNo + 1;
            echo "<li class='page-item'><a class='page-link' href='./users.php?p=$pageNo'>Next</a></li>";
          }
        }
      ?>
    </ul>

    <!-- Delete Compnay Modal -->
    <div class="modal fade" id="delete-user-modal" tabindex="-1">
      <div class="modal-dialog" role="document">
        <div class="p-4 modal-content">
          <span class="position-absolute modal-cross" data-dismiss="modal">
            <i class="fas fa-times"></i>
          </span>
          <h3 class="my-4 text-danger text-center modal-heading">You sure suspending this user forever?</h3>
          <form onsubmit="deleteUser(event)" class="delete-user-form" id="delete-user-form" data-user-id="">
            <div class="text-center delete-user-btn-container">
              <button class="btn btn-danger shadow-none delete-user-btn" id="delete-user-btn">Suspend</button>
            </div>
            <div class="d-none mt-4 text-center res-msg-container">
              <!-- response goes here -->
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>

  <!-- Shared -->
  <script src="../assets/js/shared/font-awesome.min.js"></script>
  <script src="../assets/js/shared/jquery.min.js"></script>
  <script src="../assets/js/shared/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/shared/main.js"></script>
  <!-- Admin -->
  <script src="../assets/js/admin/users.js"></script>
  <script src="../assets/js/admin/logout.js"></script>
</body>
</html>