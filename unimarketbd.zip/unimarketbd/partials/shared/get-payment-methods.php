<?php
  function getPaymentMethods() {
    if(!isset($_SESSION['userLoginDetails']['id']) || !isset($_SESSION['userLoginDetails']['orderId'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate PaymentMethods object
    $paymentMethods = new PaymentMethods($db);

    // get all payment methods
    $stmt = $paymentMethods->read();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $row;
  }
?>