<?php
  function getByPageOrders($curPageNo) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderStatusesHistory object
    $orderStatusesHistory = new OrderStatusesHistory($db);

    // set properties
    $orderStatusesHistory->p = $curPageNo;
    $orderStatusesHistory->rowsPerPage = (int) ADMIN_ROWS_PER_PAGE;

    // get orderStatusesHistory by page
    $stmt = $orderStatusesHistory->readByPage();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $orders;
  }
?>