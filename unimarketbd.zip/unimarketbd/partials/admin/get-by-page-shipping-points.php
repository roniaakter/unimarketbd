<?php
  function getByPageShippingPoints($curPageNo) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate ShippingPoints object
    $shippingPoints = new ShippingPoints($db);

    // set properties
    $shippingPoints->p = $curPageNo;
    $shippingPoints->rowsPerPage = (int) ADMIN_ROWS_PER_PAGE;

    // get shippingPoints by page
    $stmt = $shippingPoints->readByPage();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $shippingPoints = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $shippingPoints;
  }
?>