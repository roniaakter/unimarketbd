<?php
  function sideBarHTML() {
    $html = 
    "<aside class='bg-white border-right position-fixed sidebar'>
      <a href='../admin' class='d-flex justify-content-center align-items-center px-3 border-bottom nav-link logo'>
        UnimarketBd - Admin Panel
      </a>
      <ul class='nav-items'>
        <li class='nav-item'>
          <a href='../admin' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Dashboard
          </a>
        </li>
        <li class='nav-item'>
          <a href='./categories.php' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Categories
          </a>
        </li>
        <li class='nav-item'>
          <a href='./companies.php' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Companies
          </a>
        </li>
        <li class='nav-item'>
          <a href='./users.php' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Users
          </a>
        </li>
        <li class='nav-item'>
          <a href='./products.php' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Products
          </a>
        </li>
        <li class='nav-item'>
          <a href='./shipping-points.php' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Shipping Points
          </a>
        </li>
        <li class='nav-item'>
          <a href='./orders.php' class='text-dark nav-link'>
            <span class='d-inline-block nav-link-icon'>
              <i class='fas fa-chevron-right'></i>
            </span>
            Orders
          </a>
        </li>
      </ul>
    </aside>";

    return $html;
  }
?>