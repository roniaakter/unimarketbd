<?php
  function getBasicInfoOfOrder($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Orders object
    $orders = new Orders($db);

    // set properties
    $orders->id = $orderId;

    // get basic info of each order
    $stmt = $orders->readBasicInfoOfOrder();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $orderBasicInfo = $stmt->fetch(PDO::FETCH_ASSOC);

    return $orderBasicInfo;
  }
?>