<?php
  function getPageCountCompanies() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Companies object
    $companies = new Companies($db);

    // get all companies
    $stmt = $companies->read();
    $rowCount = $stmt->rowCount();

    $totalPages = ceil($rowCount / (int) ADMIN_ROWS_PER_PAGE);

    return $totalPages;
  }
?>