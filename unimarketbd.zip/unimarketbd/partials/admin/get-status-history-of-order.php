<?php
  function getStatusHistoryOfOrder($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderStatusesHistory object
    $orderStatusesHistory = new OrderStatusesHistory($db);

    // set properties
    $orderStatusesHistory->orderId = $orderId;

    // get product items of each order
    $stmt = $orderStatusesHistory->readByOrderIdExceptInstantiated();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $orderStatuses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $orderStatuses;
  }
?>