<?php
  function getPageCountShippingPoints() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate ShippingPoints object
    $shippingPoints = new ShippingPoints($db);

    // get all shippingPoints
    $stmt = $shippingPoints->read();
    $rowCount = $stmt->rowCount();

    $totalPages = ceil($rowCount / (int) ADMIN_ROWS_PER_PAGE);

    return $totalPages;
  }
?>