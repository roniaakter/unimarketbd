<?php
  function getByPageCategories($curPageNo) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Categories object
    $categories = new Categories($db);

    // set properties
    $categories->p = $curPageNo;
    $categories->rowsPerPage = (int) ADMIN_ROWS_PER_PAGE;

    // get categories by page
    $stmt = $categories->readByPage();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $categories;
  }
?>