<?php
  function loginWithCookie() {
    if(!isset($_COOKIE['adminUsername']) || !isset($_COOKIE['adminPassword'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Admins object
    $admins = new Admins($db);

    // set properties
    $admins->username = trim($_COOKIE['adminUsername']);
    $admins->hashedPassword = trim($_COOKIE['adminPassword']);

    // read a single admin
    $stmt = $admins->readByUsernameHashedPassword();

    if(!$stmt->rowCount()) return;

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    $_SESSION['adminLoginDetails']['id'] = $row['id'];
  }
?>