<?php
  function getProductItemsOfOrder($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderContains object
    $orderContains = new OrderContains($db);

    // set properties
    $orderContains->orderId = $orderId;

    // get product items of each order
    $stmt = $orderContains->readByOrderId();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $orderProductItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $orderProductItems;
  }
?>