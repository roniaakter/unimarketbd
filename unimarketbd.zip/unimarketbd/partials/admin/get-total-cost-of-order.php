<?php
  function getTotalCostOfOrder($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderContains object
    $orderContains = new OrderContains($db);

    // set properties
    $orderContains->orderId = $orderId;

    // get basic info of each order
    $stmt = $orderContains->readTotalCost();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $totalCostOfOrderRow = $stmt->fetch(PDO::FETCH_ASSOC);

    return $totalCostOfOrderRow['totalCost'];
  }
?>