<?php
  function getWishlistCount() {
    if(!isset($_SESSION['userLoginDetails']['id'])) return 0;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Wishlist object
    $wishlist = new Wishlist($db);

    // set properties
    $wishlist->userId = $_SESSION['userLoginDetails']['id'];

    // get all wishlist
    $stmt = $wishlist->readByUserId();
    $rowCount = $stmt->rowCount();

    return $rowCount > 9 ? '9+' : $rowCount;
  }
?>