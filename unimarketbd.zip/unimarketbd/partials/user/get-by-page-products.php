<?php
  function getByPageProducts($curPageNo, $q) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Products object
    $products = new Products($db);

    // set properties
    $products->p = $curPageNo;
    $products->q = $q;
    $products->rowsPerPage = (int) USER_PRODUCTS_PER_PAGE;

    // get products by page
    $stmt = $products->readByPageQ();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return false;

    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $products;
  }
?>