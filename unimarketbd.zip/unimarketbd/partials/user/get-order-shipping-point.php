<?php
  function getOrderShippingPoint($shippingPointId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate ShippingPoints object
    $shippingPoints = new ShippingPoints($db);

    // set properties
    $shippingPoints->id = $shippingPointId;

    // get shipping point of the order
    $stmt = $shippingPoints->readById();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row['name'];
  }
?>