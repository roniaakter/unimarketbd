<?php
  function getOrdersCount() {
    if(!isset($_SESSION['userLoginDetails']['id'])) return 0;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Orders object
    $orders = new Orders($db);

    // set properties
    $orders->userId = $_SESSION['userLoginDetails']['id'];

    // get all orders of the user
    $stmt = $orders->readTotalOrdersOfUser();
    $rowCount = $stmt->rowCount();

    return $rowCount > 9 ? '9+' : $rowCount;
  }
?>