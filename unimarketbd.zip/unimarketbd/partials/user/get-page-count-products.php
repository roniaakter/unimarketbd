<?php
  function getPageCountProducts() {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Products object
    $products = new Products($db);

    // get all products
    $stmt = $products->read();
    $rowCount = $stmt->rowCount();

    $totalPages = ceil($rowCount / (int) USER_PRODUCTS_PER_PAGE);

    return $totalPages;
  }
?>