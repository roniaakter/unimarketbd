<?php
  function returnOrderButtonHTML($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderStatusesHistory object
    $orderStatusesHistory = new OrderStatusesHistory($db);

    // set properties
    $orderStatusesHistory->orderId = $orderId;

    // get orderStatusesHistory by page
    $stmt = $orderStatusesHistory->readLastByOrderId();
    $rowCount = $stmt->rowCount();

    if(!$rowCount) return;

    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($row['status'] != 'Received') return;

    return 
    "<div class='pt-3 text-center cancel-order-container'>
      <button onclick='changeOrderStatus($orderId)' class='btn btn-danger btn-sm'>Return Order</button>
    </div>";
  }
?>