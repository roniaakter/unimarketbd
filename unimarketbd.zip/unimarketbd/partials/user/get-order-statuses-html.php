<?php
  function getOrderStatusesHistoryHTML($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderStatusesHistory object
    $orderStatusesHistory = new OrderStatusesHistory($db);

    // set properties
    $orderStatusesHistory->orderId = $orderId;

    // get all order statuses history of the order
    $stmt = $orderStatusesHistory->readByOrderIdExceptInstantiated();

    if(!$stmt->rowCount()) return;

    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $html = 
    "<div class='dropdown each-order-statuses'>
      <button class='btn border shadow-none dropdown-toggle' type='button' id='orderStatusesHistoryDropdown' data-toggle='dropdown'>
        Details
      </button>
      <div class='dropdown-menu'>";

    foreach ($result as $row) {
      extract($row);

      $changedAt = date("F j, Y, g:i a", strtotime($changedAt));

      $html .= 
      "<span class='d-flex align-items-center dropdown-item'>
        $status 
        <span class='mx-2'>-</span>
        $changedAt
      </span>";
    }

    $html .=
      "</div>
    </div>";

    return $html;
  }
?>