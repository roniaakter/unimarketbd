<?php
  function getOrderTotalCost($orderId) {
    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate OrderContains object
    $orderContains = new OrderContains($db);

    // set properties
    $orderContains->orderId = $orderId;

    // get total cost of the order
    $stmt = $orderContains->readTotalCost();

    if(!$stmt->rowCount()) return false;

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    return $row['totalCost'];
  }
?>