<?php
  function getWishlist() {
    if(!isset($_SESSION['userLoginDetails']['id'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Wishlist object
    $wishlist = new Wishlist($db);

    // set properties
    $wishlist->userId = $_SESSION['userLoginDetails']['id'];

    // get all wishlist
    $stmt = $wishlist->readByUserIdWithProducts();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $row;
  }
?>