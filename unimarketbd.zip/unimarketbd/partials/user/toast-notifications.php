<?php
  function toastNotifications() {
    $html =
    "<div class='position-fixed toast-notifications' id='toast-notifications'></div>";

    return $html; 
  }
?>

