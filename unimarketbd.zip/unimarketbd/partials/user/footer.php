<?php
  function footer() {
    return 
    "<footer class='mt-5'>
      <div class='container py-3 text-center border-top'>
        Copyright © ".date("Y")." UnimarketBd. All Rights Reserved
      </div>
    </footer>";
  }
?>