<?php
  function getCart() {
    if(!isset($_SESSION['userLoginDetails']['id']) || !isset($_SESSION['userLoginDetails']['orderId'])) return;

    // instantiate db & connect
    $database = new Database();
    $db = $database->connect();

    // instantiate Cart object
    $cart = new Cart($db);

    // set properties
    $cart->orderId = $_SESSION['userLoginDetails']['orderId'];

    // get all cart items
    $stmt = $cart->readByOrderIdWithProducts();
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $row;
  }
?>