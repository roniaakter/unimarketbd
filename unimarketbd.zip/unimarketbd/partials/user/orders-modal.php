<?php
  function showOrders($orderIds) {
    if(!$orderIds) return "<div class='no-order-item text-center' id='no-order-item'>No orders yet</div>";

    $html = "";

    foreach ($orderIds as $orderId) {
      extract($orderId);

      $html .= "<div class='order-item py-3'>";

      $html .= 
      "<div class='d-flex flex-column align-items-center order-basic-details'>
        <span class='each-order-id'>
          Order ID: <span class='text-primary'>#$id</span>
        </span>
        <span class='d-inline-block my-2 each-order-shipping-point'>
          Shipping Point: <span class='text-primary'>".getOrderShippingPoint($shippingPointId)."</span>
        </span>
        ".getOrderStatusesHistoryHTML($id)."
      </div>";

      $html .=
      returnOrderButtonHTML($id);

      $html .= 
      "<ul class='my-4 list-unstyled each-order-items'>";

      if(getEachOrderItems($id)) {
        foreach(getEachOrderItems($id) as $eachOrderItem) {
          $imgURL = glob("./assets/img/shared/products/".$eachOrderItem['productId'].".*")[0];

          $html .= 
          "<li class='d-flex align-items-center each-order-item'>
            <img width='60' src='$imgURL' class='each-order-item-product-img'/>
            <span class='ml-4 each-order-item-product-quantity'>".$eachOrderItem['productQuantity']."</span>
            <span class='ml-4 each-order-item-multiply-icon'>x</span>
            <div class='ml-4 d-flex flex-column each-order-item-product-info'>
              <span class='text-primary each-order-item-product-name'>".$eachOrderItem['productName']."</span>
              <span class='each-order-item-category-name'>
                From <span class='text-primary'>".$eachOrderItem['productCategoryName']."</span>
              </span>
              <span class='each-order-item-company-name'>
                By <span class='text-primary'>".$eachOrderItem['productCompanyName']."</span>
              </span>
              <span class='each-order-item-product-price-cost'>
                ".$eachOrderItem['productUnitPrice']." TK (+".$eachOrderItem['productShippingCost']." TK)
              </span>
            </div>
            <span class='ml-4 each-order-item-equal-icon'>=</span>
            <span class='ml-4 each-order-item-individual-total'>".number_format(($eachOrderItem['productUnitPrice'] * $eachOrderItem['productQuantity']) + $eachOrderItem['productShippingCost'], 2)." TK</span>
          </li>";
        }
      }

      $html .=
      "</ul>";

      $html .= 
      "<div class='text-center total-order-cost-container'>
        <span class='total-order-cost'>
          Total: ".getOrderTotalCost($id)." TK
        </span>
      </div>";

      $html .= "</div>";
    }

    return $html;
  }

  function ordersModal() {
    $html = isset($_SESSION['userLoginDetails']) ?
    "<div class='modal fade' id='ordersModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='p-4 modal-content'>
          <span class='position-absolute modal-cross' data-dismiss='modal'>
            <i class='fas fa-times'></i>
          </span>
          <h3 class='my-4 text-primary text-center modal-heading'>My Orders</h3>
          <div class='order-items' id='order-items'>
            ".showOrders(getOrderIds())."
          </div>
        </div>
      </div>
    </div>" : 
    "<div class='modal fade' id='ordersModal' tabindex='-1' role='dialog'>
      <div class='modal-dialog' role='document'>
        <div class='p-4 modal-content'>
          <span class='position-absolute modal-cross' data-dismiss='modal'>
            <i class='fas fa-times'></i>
          </span>
          <h3 class='my-4 text-dark text-center modal-heading'>Please, login to see your orders</h3>
          <a href='".SITE_URL."/login.php' class='btn btn-primary align-self-center'>Login</a>
        </div>
      </div>
    </div>";

    return $html;
  }
?>