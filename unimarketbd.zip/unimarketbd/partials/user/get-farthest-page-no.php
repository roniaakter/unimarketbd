<?php
  /* 
    1. Return leftMost and rightMost page no. in pagination 
    2. Total pages and current page are to be passed
    3. Clone fiverr pagination styling
  */

  function getFarthestPageNo($totalPages, $currentPage) {
    $maxPages = (int) USER_PRODUCTS_COUNT_IN_PAGINATION;

    $maxPagesOnLeft = (int) ($maxPages / 2);
    $maxPagesOnRight = ($maxPages % 2) ? (int) ($maxPages / 2) : ((int) ($maxPages / 2) - 1);

    $leftMost = 1;
    $rightMost = $totalPages;
  
    if($currentPage - $maxPagesOnLeft >= 1 && $currentPage + $maxPagesOnRight <= $totalPages) {
      $leftMost = $currentPage - $maxPagesOnLeft;
      $rightMost = $currentPage + $maxPagesOnRight;
    } else if($currentPage - $maxPagesOnLeft >= 1) {
      $leftMost = max(1, $totalPages - $maxPages + 1);
    } else if($currentPage + $maxPagesOnRight <= $totalPages) {
      $rightMost = min($maxPages, $totalPages);
    }
  
    return [
      'leftMost' => $leftMost,
      'rightMost' => $rightMost
    ];
  }
?>