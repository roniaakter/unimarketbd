var changeOrderStatusProcessing = false;

function changeOrderStatus(event) {
  $.ajax({
    url: '../api/admin/update-order-status.php',
    method: 'POST',
    data: JSON.stringify({
      orderId: $(event.target).attr('data-order-id'),
      status: $(event.target).attr('data-order-status')
    }),
    beforeSend: function() {
      changeOrderStatusProcessing = true;
    },
    success: function(res) {
      location.reload();
    },
    error: function(err) {
      console.log(err);
    },
    complete: function() {
      changeOrderStatusProcessing = false;
    }
  });
}