var createCompanyForm = $('#create-company-form');
var createCompanyBtn = $('#create-company-btn');
var createCompanyResMsgContainer = $('#create-company-form .res-msg-container');

var deleteCompanyForm = $('#delete-company-form');
var deleteCompanyBtn = $('#delete-company-btn');
var deleteCompanyResMsgContainer = $('#delete-company-form .res-msg-container');

function createCompany(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/create-company.php',
    method: 'POST',
    data: JSON.stringify({
      name: $('#create-company-name').val(),
      location: $('#create-company-location').val(),
      description: $('#create-company-desc').val()
    }),
    beforeSend: function() {
      createCompanyBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      createCompanyResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      createCompanyResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      createCompanyBtn.removeAttr('disabled');
    }
  });
}

function deleteCompanyPre(event) {
  var id = $(event.target).tagName == 'button' ? $(event.target).attr('data-company-id') :  $(event.target).closest('button').attr('data-company-id');
  deleteCompanyForm.attr('data-company-id', id);
}

function deleteCompany(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/delete-company.php',
    method: 'DELETE',
    data: JSON.stringify({
      id: deleteCompanyForm.attr('data-company-id')
    }),
    beforeSend: function() {
      deleteCompanyBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      deleteCompanyResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      deleteCompanyResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      deleteCompanyBtn.removeAttr('disabled');
    }
  });
}