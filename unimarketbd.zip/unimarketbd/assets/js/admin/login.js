var loginForm = $('#login-form');
var loginBtn = $('#login-btn');
var loginResMsgContainer = $('#login-form .res-msg-container');

function login(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/login.php',
    method: 'POST',
    data: JSON.stringify({
      usernameEmail: $('#username-email').val(),
      password: $('#password').val(),
      rememberMe: $('#remember-me').is(':checked')
    }),
    beforeSend: function() {
      loginBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(res) {
      console.log(res);
      loginResMsgContainer.html(`<span class="text-danger">${res.responseJSON.message}</span>`);
      loginResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      loginBtn.removeAttr('disabled');
    }
  });
}