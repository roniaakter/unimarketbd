var createCategoryForm = $('#create-category-form');
var createCategoryBtn = $('#create-category-btn');
var createCategoryResMsgContainer = $('#create-category-form .res-msg-container');

var deleteCategoryForm = $('#delete-category-form');
var deleteCategoryBtn = $('#delete-category-btn');
var deleteCategoryResMsgContainer = $('#delete-category-form .res-msg-container');

function createCategory(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/create-category.php',
    method: 'POST',
    data: JSON.stringify({
      name: $('#create-category-name').val()
    }),
    beforeSend: function() {
      createCategoryBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      console.log(err);
      createCategoryResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      createCategoryResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      createCategoryBtn.removeAttr('disabled');
    }
  });
}

function deleteCategoryPre(event) {
  var id = $(event.target).tagName == 'button' ? $(event.target).attr('data-category-id') :  $(event.target).closest('button').attr('data-category-id');
  deleteCategoryForm.attr('data-category-id', id);
}

function deleteCategory(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/delete-category.php',
    method: 'DELETE',
    data: JSON.stringify({
      id: deleteCategoryForm.attr('data-category-id')
    }),
    beforeSend: function() {
      deleteCategoryBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      deleteCategoryResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      deleteCategoryResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      deleteCategoryBtn.removeAttr('disabled');
    }
  });
}