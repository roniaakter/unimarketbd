var createProductForm = $('#create-product-form');
var createProductBtn = $('#create-product-btn');
var createProductResMsgContainer = $('#create-product-form .res-msg-container');
var editProductResMsgContainer = $('#edit-product-form .res-msg-container');

var deleteProductForm = $('#delete-product-form');
var deleteProductBtn = $('#delete-product-btn');
var deleteProductResMsgContainer = $('#delete-product-form .res-msg-container');

function createProduct(event) {
  event.preventDefault();

  var formData = new FormData();

  var createProductImg = document.getElementById('create-product-img');

  formData.append('name', $('#create-product-name').val());  
  formData.append('categoryId', $('#create-product-category').val());  
  formData.append('companyId', $('#create-product-company').val());  
  formData.append('unitPrice', $('#create-product-unit-price').val());  
  formData.append('shippingCost', $('#create-product-shipping-cost').val());  
  formData.append('unitShippingCost', $('#create-product-unit-shipping-cost').val());  
  formData.append('image', createProductImg.files[0]);  
  formData.append('stockUnits', $('#create-product-stock-units').val());  
  formData.append('description', $('#create-product-desc').val());  

  $.ajax({
    url: '../api/admin/create-product.php',
    method: 'POST',
    data: formData,
    processData: false,
    contentType: false,
    beforeSend: function() {
      createProductBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      console.log(err);
      createProductResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      createProductResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      createProductBtn.removeAttr('disabled');
    }
  });
}

function editProductPre(event) {
  var tr = $(event.target).closest('tr');

  $('#edit-product-id').val(tr.find('.id').text());
  $('#edit-product-name').val(tr.find('.name').text());
  $('#edit-product-category').val(tr.find('.category').attr('data-category-id'));
  $('#edit-product-company').val(tr.find('.company').attr('data-company-id'));
  $('#edit-product-unit-price').val(tr.find('.unit-price').attr('data-unit-price'));
  $('#edit-product-shipping-cost').val(tr.find('.shipping-cost').attr('data-shipping-cost'));
  $('#edit-product-desc').val(tr.find('.description').text());
  $('#edit-product-stock-units').val(tr.find('.stock-units').text());
}

function editProduct(event) {
  event.preventDefault();

  var formData = new FormData();

  var editProductImg = document.getElementById('edit-product-img');

  formData.append('id', $('#edit-product-id').val());  
  formData.append('name', $('#edit-product-name').val());  
  formData.append('categoryId', $('#edit-product-category').val());  
  formData.append('companyId', $('#edit-product-company').val());  
  formData.append('unitPrice', $('#edit-product-unit-price').val());  
  formData.append('shippingCost', $('#edit-product-shipping-cost').val());  
  formData.append('image', editProductImg.files[0]);  
  formData.append('stockUnits', $('#edit-product-stock-units').val());  
  formData.append('description', $('#edit-product-desc').val());  

  $.ajax({
    url: '../api/admin/edit-product.php',
    method: 'POST',
    data: formData,
    processData: false,
    contentType: false,
    beforeSend: function() {
      createProductBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      console.log(err);
      createProductResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      createProductResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      createProductBtn.removeAttr('disabled');
    }
  });
}

function deleteProductPre(event) {
  var id = $(event.target).tagName == 'button' ? $(event.target).attr('data-product-id') :  $(event.target).closest('button').attr('data-product-id');
  deleteProductForm.attr('data-product-id', id);
}

function deleteProduct(event) {
  event.preventDefault();

  $.ajax({
    url: '../api/admin/delete-product.php',
    method: 'DELETE',
    data: JSON.stringify({
      id: deleteProductForm.attr('data-product-id')
    }),
    beforeSend: function() {
      deleteProductBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      console.log(err);
      deleteProductResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      deleteProductResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      deleteProductBtn.removeAttr('disabled');
    }
  });
}