var toastNotifications = $('#toast-notifications');

function showToastNotification(message) {
  var toastNotification = document.createElement('div');
  toastNotification.className = 'mt-3 px-4 py-2 rounded bg-warning toast-notification';
  toastNotification.innerText = message;

  toastNotifications.append(toastNotification);

  setTimeout(() => {
    toastNotification.remove();
  }, 3000);
}