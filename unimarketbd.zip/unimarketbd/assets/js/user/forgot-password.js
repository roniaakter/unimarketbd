var emailVerificationForm = $('#email-verification-form');
var matchRecoveryCodeForm = $('#match-recovery-code-form');
var resetPasswordForm = $('#reset-password-form');
var verifyBtn = $('#verify-btn');
var matchRecoveryCodeBtn = $('#match-recovery-code-btn');
var resetPasswordBtn = $('#reset-password-btn');
var emailVerificationResMsgContainer = $('#email-verification-form .res-msg-container');
var matchRecoveryCodeResMsgContainer = $('#match-recovery-code-form .res-msg-container');
var resetPasswordResMsgContainer = $('#reset-password-form .res-msg-container');

function emailVerification(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/fp-verify-email.php',
    method: 'POST',
    data: JSON.stringify({
      email: $('#email').val()
    }),
    beforeSend: function() {
      verifyBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      $('form').addClass('d-none');
      matchRecoveryCodeForm.removeClass('d-none');
    },
    error: function(err) {
      emailVerificationResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      emailVerificationResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      verifyBtn.removeAttr('disabled');
    }
  });
}

function matchRecoveryCode(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/fp-match-code.php',
    method: 'POST',
    data: JSON.stringify({
      recoveryCode: $('#recovery-code').val()
    }),
    beforeSend: function() {
      matchRecoveryCodeBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      $('form').addClass('d-none');
      resetPasswordForm.removeClass('d-none');
    },
    error: function(err) {
      matchRecoveryCodeResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      matchRecoveryCodeResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      matchRecoveryCodeBtn.removeAttr('disabled');
    }
  });
}


function resetPassword(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/fp-reset.php',
    method: 'POST',
    data: JSON.stringify({
      passwordNew: $('#password-new').val(),
      passwordConfirm: $('#password-confirm').val()
    }),
    beforeSend: function() {
      resetPasswordBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      resetPasswordResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      resetPasswordResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      resetPasswordBtn.removeAttr('disabled');
    }
  });
}