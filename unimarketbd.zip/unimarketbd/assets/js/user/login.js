var registerForm = $('#register-form');
var loginForm = $('#login-form');
var registerChooseText = $('#register-choose-text');
var loginChooseText = $('#login-choose-text');
var registerBtn = $('#register-btn');
var loginBtn = $('#login-btn');
var registerResMsgContainer = $('#register-form .res-msg-container');
var loginResMsgContainer = $('#login-form .res-msg-container');

function toggleLoginRegisterForm() {
  loginChooseText.toggleClass('text-primary');
  registerChooseText.toggleClass('text-primary');

  loginForm.toggleClass('d-none');
  registerForm.toggleClass('d-none');
}

function register(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/register-send-code.php',
    method: 'POST',
    data: JSON.stringify({
      username: $('#register-username').val(),
      email: $('#register-email').val(),
      passwordNew: $('#register-password-new').val(),
      passwordConfirm: $('#register-password-confirm').val()
    }),
    beforeSend: function() {
      registerBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      console.log(err);
      registerResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      registerResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      registerBtn.removeAttr('disabled');
    }
  });
}

function login(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/login.php',
    method: 'POST',
    data: JSON.stringify({
      usernameEmail: $('#login-username-email').val(),
      password: $('#login-password').val(),
      rememberMe: $('#remember-me').is(':checked')
    }),
    beforeSend: function() {
      loginBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(err) {
      loginResMsgContainer.html(`<span class="text-danger">${err.responseJSON.message}</span>`);
      loginResMsgContainer.removeClass('d-none');
    },
    complete: function() {
      loginBtn.removeAttr('disabled');
    }
  });
}