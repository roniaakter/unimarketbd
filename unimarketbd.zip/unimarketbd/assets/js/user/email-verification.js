var verifyBtn = $('#verify-btn');
var resMsgContainer = $('.res-msg-container');

function emailVerification(event) {
  event.preventDefault();

  $.ajax({
    url: './api/user/register-verify-email.php',
    method: 'POST',
    data: JSON.stringify({
      verificationCode: $('#verification-code').val()
    }),
    beforeSend: function() {
      verifyBtn.attr('disabled', 'disabled');
    },
    success: function(res) {
      window.location.href = res.redirectURL;
    },
    error: function(res) {
      resMsgContainer.html(`<span class="text-danger">${res.responseJSON.message}</span>`);
      resMsgContainer.removeClass('d-none');
    },
    complete: function() {
      verifyBtn.removeAttr('disabled');
    }
  });
}