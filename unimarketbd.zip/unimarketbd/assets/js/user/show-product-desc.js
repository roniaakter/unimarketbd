function showProductDesc(e) {
  var productCard = $(e.target).closest('.product.card');

  $('#showProductDescModal .product-desc__product-img').attr('src', productCard.find('.product-img').attr('src'))
  $('#showProductDescModal .product-desc__product-name').text(productCard.find('.product-name').text());
  $('#showProductDescModal .product-desc__category-name').html(`From <span class="text-primary text-decoration-underline">${productCard.find('.product-category span').text()}</span>`);
  $('#showProductDescModal .product-desc__company-name').html(`From <span class="text-primary text-decoration-underline">${productCard.find('.product-company span').text()}</span>`);
  $('#showProductDescModal .product-desc__product-price').text(productCard.find('.product-price-cost').text());
  $('#showProductDescModal .product-desc_product-desc').text(productCard.find('.product-desc').text());
}