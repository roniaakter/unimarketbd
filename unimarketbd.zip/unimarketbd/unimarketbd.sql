-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2023 at 07:57 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `unimarketbd`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `email`, `password`, `createdAt`, `lastUpdated`) VALUES
(12012031, 'RO072324', 'roniaakter51@gmail.com', '$2y$10$6ZsLE53yZrsq01VRKPgtyus8vwu7M7U/MPr6JXpWUc1XQhAFlAcr2', '2023-01-10 04:20:45', '2023-01-10 04:20:45');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`orderId`, `productId`, `quantity`) VALUES
(25, 38, 1),
(26, 32, 1),
(27, 46, 6),
(28, 46, 2),
(30, 38, 1),
(30, 36, 1),
(30, 44, 1),
(31, 38, 1),
(32, 43, 1),
(32, 46, 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `createdAt`, `lastUpdated`) VALUES
(3, 'Soft Drinks', '2021-05-25 09:31:55', '2021-05-25 09:31:55'),
(4, 'Juice', '2021-05-27 08:30:56', '2021-05-27 08:30:56'),
(5, 'Fruits', '2021-05-27 08:31:04', '2021-05-27 08:31:04'),
(6, 'Plastic', '2023-03-30 01:27:37', '2023-03-30 01:27:37'),
(7, 'Book', '2023-03-30 01:27:43', '2023-03-30 01:27:43'),
(8, 'Furniture', '2023-03-30 01:29:05', '2023-03-30 01:29:05'),
(9, 'Electronics', '2023-03-30 01:36:37', '2023-03-30 01:36:37');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `location` varchar(40) NOT NULL,
  `description` varchar(500) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `location`, `description`, `createdAt`, `lastUpdated`) VALUES
(17, 'Fruit Kingdom', 'Rupatoli, Barishal - 8200', 'House of non-preservative fruits!', '2021-05-27 08:33:14', '2021-05-27 08:33:14'),
(18, 'RFL', 'Dhaka', 'Office chair produced by RFL company', '2023-03-30 01:28:37', '2023-03-30 01:28:37'),
(19, 'Sony', 'Dhaka', 'Electronics Product', '2023-03-30 01:39:07', '2023-03-30 01:39:07'),
(20, 'Samsung', 'Dhaka', 'Electronics Product', '2023-03-30 01:39:24', '2023-03-30 01:39:24'),
(21, 'Vision', 'Dhaka', 'Electronics Product Supply', '2023-03-30 01:54:51', '2023-03-30 01:54:51'),
(22, 'Marino', 'Dhaka', 'Bottle supply', '2023-03-30 02:02:45', '2023-03-30 02:02:45'),
(23, 'Casio', 'Dhaka', 'Scientific Calculator supply', '2023-03-30 02:05:47', '2023-03-30 02:05:47'),
(24, 'Tata McGraw Hill Education', 'New Delhi', 'Computer Science and Engineering book', '2023-03-30 02:59:08', '2023-03-30 02:59:08'),
(25, 'HP', 'Dhaka', 'Computer series', '2023-03-30 03:30:07', '2023-03-30 03:30:07');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `shippingPointId` int(11) DEFAULT NULL,
  `paymentMethodId` int(11) DEFAULT NULL,
  `userLocation` varchar(255) DEFAULT NULL,
  `phoneNum` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `shippingPointId`, `paymentMethodId`, `userLocation`, `phoneNum`) VALUES
(23, 15, 1, NULL, 'Barishal', '01967796110'),
(24, 15, NULL, NULL, NULL, NULL),
(25, 15, 1, NULL, 'khulna', '01739450391'),
(26, 15, 2, NULL, 'BU', '01967796110'),
(27, 15, 1, NULL, 'Barishal University', '01966796110'),
(28, 15, 1, NULL, 'Khulna', '01967796110'),
(29, 15, NULL, NULL, NULL, NULL),
(30, 15, 1, NULL, 'Barishal University', '01967796110'),
(31, 15, 1, NULL, 'Barishal University', '0173950391'),
(32, 15, 1, NULL, 'Barishal University', '01966796110'),
(33, 15, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_contains`
--

CREATE TABLE `order_contains` (
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `productName` varchar(30) NOT NULL,
  `productCategoryName` varchar(30) NOT NULL,
  `productCompanyName` varchar(30) NOT NULL,
  `productUnitPrice` decimal(10,2) NOT NULL,
  `productShippingCost` decimal(10,2) NOT NULL,
  `productQuantity` int(11) NOT NULL,
  `productDescription` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_contains`
--

INSERT INTO `order_contains` (`orderId`, `productId`, `productName`, `productCategoryName`, `productCompanyName`, `productUnitPrice`, `productShippingCost`, `productQuantity`, `productDescription`) VALUES
(23, 25, 'Office Chair', 'Furniture', 'RFL', '2500.00', '200.00', 2, 'Official Chair produced by RFL'),
(25, 38, 'Mini Bluetooth Keyboard', 'Electronics', 'Samsung', '1300.00', '100.00', 1, 'The keyboard is light and thin at just 6mm. This keyboard supports iOS, Android, Windows, and Mac and is Bluetooth 3.0 standard interface. The keyboard has a 110mAh capacity battery that can work continuously for more than 40 hours. This keyboard takes less than 2 hours to fully charge. This mouse has a built-in 150mA lithium battery that can last for more than 40 hours. The mouse comes with a micro USB cable that can be charged in about 2 hours.'),
(26, 32, 'Reading Table', 'Furniture', 'RFL', '2500.00', '200.00', 1, 'Reading Table by RFL'),
(27, 46, 'Understanding Unix Programming', 'Book', 'Tata McGraw Hill Education', '350.00', '50.00', 6, 'Understanding Unix/Linux Programming\r\nA Guide to Theory and Practice'),
(30, 38, 'Mini Bluetooth Keyboard', 'Electronics', 'Samsung', '1300.00', '100.00', 1, 'The keyboard is light and thin at just 6mm. This keyboard supports iOS, Android, Windows, and Mac and is Bluetooth 3.0 standard interface. The keyboard has a 110mAh capacity battery that can work continuously for more than 40 hours. This keyboard takes less than 2 hours to fully charge. This mouse has a built-in 150mA lithium battery that can last for more than 40 hours. The mouse comes with a micro USB cable that can be charged in about 2 hours.'),
(30, 36, 'Marino water bottle', 'Plastic', 'Marino', '200.00', '50.00', 1, 'Marino Water Bottle 700 ML -F01\r\nItem Code: 851637\r\n Brand: Marino  Water Bottle\r\n\r\n Product type: Water Bottle \r\nSize: 700 ml\r\n Material: Polycarbonate \r\nColor: As given picture'),
(30, 44, 'HP wireless Mouse', 'Electronics', 'HP', '1200.00', '50.00', 1, 'Product Store : Wireless Mouse\r\nBrand: HP\r\nColor: Black\r\nButtons: 6\r\nConnectivity: Wireless 2.4g\r\nTechnology: Optical\r\nVoltage: 3v\r\nDesign : Ergonomic\r\nBattery: 2 * AAA (not included)\r\nTransmission Distance: Up to 10m Approx.\r\nCompatibility: Windos XP / 7/8 / 8.1 / RT8 / 8.1 / 10\r\nProduct Weight: 95 Grams'),
(31, 38, 'Mini Bluetooth Keyboard', 'Electronics', 'Samsung', '1300.00', '100.00', 1, 'The keyboard is light and thin at just 6mm. This keyboard supports iOS, Android, Windows, and Mac and is Bluetooth 3.0 standard interface. The keyboard has a 110mAh capacity battery that can work continuously for more than 40 hours. This keyboard takes less than 2 hours to fully charge. This mouse has a built-in 150mA lithium battery that can last for more than 40 hours. The mouse comes with a micro USB cable that can be charged in about 2 hours.'),
(32, 43, 'Introduction to Algorithm', 'Book', 'Tata McGraw Hill Education', '350.00', '50.00', 1, 'Introduction to Algorithm\r\nThird Edition\r\nThomas H. Corman'),
(32, 46, 'Understanding Unix Programming', 'Book', 'Tata McGraw Hill Education', '350.00', '50.00', 1, 'Understanding Unix/Linux Programming\r\nA Guide to Theory and Practice');

-- --------------------------------------------------------

--
-- Table structure for table `order_statuses_history`
--

CREATE TABLE `order_statuses_history` (
  `orderId` int(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `changedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_statuses_history`
--

INSERT INTO `order_statuses_history` (`orderId`, `status`, `changedAt`) VALUES
(23, 'Instantiated', '2023-03-30 01:26:17'),
(23, 'Pending', '2023-03-30 01:31:30'),
(24, 'Instantiated', '2023-03-30 01:31:30'),
(23, 'Pending', '2023-03-30 01:31:37'),
(25, 'Instantiated', '2023-03-30 01:31:37'),
(23, 'Accepted', '2023-03-30 01:32:01'),
(25, 'Pending', '2023-03-30 02:29:07'),
(26, 'Instantiated', '2023-03-30 02:29:07'),
(25, 'Accepted', '2023-03-30 02:29:48'),
(26, 'Pending', '2023-03-30 02:30:42'),
(27, 'Instantiated', '2023-03-30 02:30:42'),
(27, 'Pending', '2023-03-30 05:16:30'),
(28, 'Instantiated', '2023-03-30 05:16:30'),
(28, 'Pending', '2023-03-30 05:17:13'),
(29, 'Instantiated', '2023-03-30 05:17:13'),
(28, 'Pending', '2023-03-30 05:17:17'),
(30, 'Instantiated', '2023-03-30 05:17:18'),
(30, 'Pending', '2023-04-01 08:41:41'),
(31, 'Instantiated', '2023-04-01 08:41:41'),
(31, 'Pending', '2023-04-01 08:43:22'),
(32, 'Instantiated', '2023-04-01 08:43:22'),
(32, 'Pending', '2023-04-01 08:44:07'),
(33, 'Instantiated', '2023-04-01 08:44:07');

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `pic` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `name`, `pic`) VALUES
(1, 'Bkash', 'assets/img/shared/payment-methods/bkash.jpg'),
(2, 'Nagad', 'assets/img/shared/payment-methods/nagad.jpg'),
(3, 'Rocket', 'assets/img/shared/payment-methods/rocket.png');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `shippingCost` decimal(10,2) NOT NULL,
  `description` varchar(500) NOT NULL,
  `hasImage` tinyint(1) DEFAULT 1,
  `categoryId` int(11) NOT NULL,
  `companyId` int(11) NOT NULL,
  `stockUnits` int(11) NOT NULL DEFAULT 100,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `unitPrice`, `shippingCost`, `description`, `hasImage`, `categoryId`, `companyId`, `stockUnits`, `createdAt`, `lastUpdated`) VALUES
(31, 'Office Chair', '3200.00', '200.00', 'Official Chair by RFL', 1, 8, 18, 10, '2023-03-30 01:52:01', '2023-03-30 01:52:01'),
(32, 'Reading Table', '2500.00', '200.00', 'Reading Table by RFL', 1, 8, 18, 9, '2023-03-30 01:53:01', '2023-03-30 01:53:01'),
(33, 'Sony Delux Table Fan', '750.00', '100.00', 'Sony Delux Table Fan By Sony', 1, 9, 19, 10, '2023-03-30 01:54:08', '2023-03-30 01:54:08'),
(34, 'Vision Rice Cooker', '1300.00', '100.00', 'Rice Cooker By Vision', 1, 9, 21, 10, '2023-03-30 01:55:57', '2023-03-30 01:55:57'),
(35, 'RFL Rack', '550.00', '100.00', 'RFL minimum rack', 1, 6, 18, 10, '2023-03-30 01:57:34', '2023-03-30 01:57:34'),
(36, 'Marino water bottle', '200.00', '50.00', 'Marino Water Bottle 700 ML -F01\r\nItem Code: 851637\r\n Brand: Marino  Water Bottle\r\n\r\n Product type: Water Bottle \r\nSize: 700 ml\r\n Material: Polycarbonate \r\nColor: As given picture', 1, 6, 22, 9, '2023-03-30 02:03:43', '2023-03-30 02:03:43'),
(37, 'Casio ES plus calculator', '1200.00', '50.00', 'Fx-991 ES Plus Scientific Calculator', 1, 9, 23, 20, '2023-03-30 02:08:07', '2023-03-30 02:08:07'),
(38, 'Mini Bluetooth Keyboard', '1300.00', '100.00', 'The keyboard is light and thin at just 6mm. This keyboard supports iOS, Android, Windows, and Mac and is Bluetooth 3.0 standard interface. The keyboard has a 110mAh capacity battery that can work continuously for more than 40 hours. This keyboard takes less than 2 hours to fully charge. This mouse has a built-in 150mA lithium battery that can last for more than 40 hours. The mouse comes with a micro USB cable that can be charged in about 2 hours.', 1, 9, 20, 2, '2023-03-30 02:12:40', '2023-03-30 02:12:40'),
(39, 'Microprocessor and Interfacing', '350.00', '50.00', 'Microprocessor and Interfacing by \r\nDouglas V Hall\r\nSSSP RA0', 1, 7, 24, 5, '2023-03-30 03:04:18', '2023-03-30 03:04:18'),
(40, 'Data Commnunication', '400.00', '50.00', 'Data Communication and Networking\r\nFourth Edition\r\nby Bechouz A. Forouzan', 1, 7, 24, 5, '2023-03-30 03:05:45', '2023-03-30 03:05:45'),
(41, 'Database System Concepts', '450.00', '50.00', 'Database System Concepts\r\nSixth Edition\r\nAbraham Siberschatz\r\nHenory F. Korth', 1, 7, 24, 10, '2023-03-30 03:07:27', '2023-03-30 03:07:27'),
(42, 'Data Structure', '300.00', '50.00', 'Schaum\'s Otlines\r\nRevised First Edition\r\nby Seymour Lipschutz', 1, 7, 24, 5, '2023-03-30 03:08:50', '2023-03-30 03:08:50'),
(43, 'Introduction to Algorithm', '350.00', '50.00', 'Introduction to Algorithm\r\nThird Edition\r\nThomas H. Corman', 1, 7, 24, 4, '2023-03-30 03:10:21', '2023-03-30 03:10:21'),
(44, 'HP wireless Mouse', '1200.00', '50.00', 'Product Store : Wireless Mouse\r\nBrand: HP\r\nColor: Black\r\nButtons: 6\r\nConnectivity: Wireless 2.4g\r\nTechnology: Optical\r\nVoltage: 3v\r\nDesign : Ergonomic\r\nBattery: 2 * AAA (not included)\r\nTransmission Distance: Up to 10m Approx.\r\nCompatibility: Windos XP / 7/8 / 8.1 / RT8 / 8.1 / 10\r\nProduct Weight: 95 Grams', 1, 9, 25, 4, '2023-03-30 03:31:13', '2023-03-30 03:31:13'),
(45, 'Mobile Computing', '350.00', '50.00', 'Fundamentals of Mobile Computing\r\nSecond Edition\r\nWritten By Prasant Kumar Pattnaik', 1, 7, 24, 5, '2023-03-30 04:55:04', '2023-03-30 04:55:04'),
(46, 'Understanding Unix Programming', '350.00', '50.00', 'Understanding Unix/Linux Programming\r\nA Guide to Theory and Practice', 1, 7, 24, 0, '2023-03-30 04:58:24', '2023-03-30 04:58:24');

-- --------------------------------------------------------

--
-- Table structure for table `shipping_points`
--

CREATE TABLE `shipping_points` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `location` varchar(40) NOT NULL,
  `description` varchar(500) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipping_points`
--

INSERT INTO `shipping_points` (`id`, `name`, `location`, `description`, `createdAt`, `lastUpdated`) VALUES
(1, 'Sundarban Courier Service', 'Forester Bari Lane, Barishal - 8200', 'Delivering your parcels with care for 3 decades!', '2021-05-28 12:04:08', '2021-05-28 12:04:08'),
(2, 'Akon Enterprise', 'Zero Point, Barishal - 8200', 'Serving our customers for years!', '2021-05-28 13:43:28', '2021-05-28 13:43:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(12) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `lastUpdated` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `createdAt`, `lastUpdated`) VALUES
(12012031, 'RO072324', 'roniaakter51@gmail.com', '$2y$10$tbNkTE9FA/HqeItL9u/a2e9Ru0dxF8dHE80d0Qd29AlD8CAr.ZYXW', '2023-01-10 04:20:12', '2023-01-10 04:20:12');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `productId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `addedAt` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`productId`, `userId`, `addedAt`) VALUES
(46, 15, '2023-03-30 05:15:59'),
(43, 15, '2023-03-30 07:42:05'),
(38, 15, '2023-03-30 07:42:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD KEY `orderId` (`orderId`),
  ADD KEY `productId` (`productId`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `userId` (`userId`),
  ADD KEY `shippingPointId` (`shippingPointId`),
  ADD KEY `paymentMethodId` (`paymentMethodId`);

--
-- Indexes for table `order_contains`
--
ALTER TABLE `order_contains`
  ADD KEY `orderId` (`orderId`);

--
-- Indexes for table `order_statuses_history`
--
ALTER TABLE `order_statuses_history`
  ADD KEY `orderId` (`orderId`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoryId` (`categoryId`),
  ADD KEY `companyId` (`companyId`);

--
-- Indexes for table `shipping_points`
--
ALTER TABLE `shipping_points`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD KEY `productId` (`productId`),
  ADD KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `shipping_points`
--
ALTER TABLE `shipping_points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`shippingPointId`) REFERENCES `shipping_points` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`paymentMethodId`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_contains`
--
ALTER TABLE `order_contains`
  ADD CONSTRAINT `order_contains_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `order_statuses_history`
--
ALTER TABLE `order_statuses_history`
  ADD CONSTRAINT `order_statuses_history_ibfk_1` FOREIGN KEY (`orderId`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`companyId`) REFERENCES `companies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `wishlist_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
