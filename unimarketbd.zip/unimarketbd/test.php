<?php
  $conn = mysqli_connect('localhost', 'root', '', 'unimarketbd');

  // create user
  $username = 'RO072324';
  $email = 'roniaakter51@gmail.com';
  $password = password_hash('12345678', PASSWORD_DEFAULT);
  $createdAt = date('Y-m-d H:i:s', time());
  $lastUpdated = date('Y-m-d H:i:s', time());

  $sql = "INSERT INTO `users`(`username`, `email`, `password`, `createdAt`, `lastUpdated`) VALUES('$username', '$email', '$password', '$createdAt', '$lastUpdated');";
  mysqli_query($conn, $sql);

  // create admin
  $username = 'indro036';
  $email = 'indro.cse.bu@gmail.com';
  $password = password_hash('12345678', PASSWORD_DEFAULT);
  $createdAt = date('Y-m-d H:i:s', time());
  $lastUpdated = date('Y-m-d H:i:s', time());

  $sql = "INSERT INTO `admins`(`username`, `email`, `password`, `createdAt`, `lastUpdated`) VALUES('$username', '$email', '$password', '$createdAt', '$lastUpdated');";
  mysqli_query($conn, $sql);
?>