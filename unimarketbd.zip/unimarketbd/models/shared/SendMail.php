<?php
  function SendMail($to, $subject, $body) {
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: UnimarketBd <no-reply@unimarket.com>" . "\r\n";

    // if(!mail($to, $subject, $body, $headers)) return false;

    return true;
  }
?>
