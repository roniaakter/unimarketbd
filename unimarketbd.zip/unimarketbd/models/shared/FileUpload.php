<?php
  function FileUpload($file, $uploadDir, $uniqueFileId, $allowedExt, $allowedMaxSize) {
    $errors = [];

    $fileName = $file['name'];
    $fileSize = $file['size'];
    $fileTmpName = $file['tmp_name'];
    $fileType = $file['type'];

    $separatedByDots = explode('.', $fileName);
    $fileExt = strtolower(end($separatedByDots));
    $fileExt = strtolower($fileExt);

    if(!in_array($fileExt, $allowedExt)) {
      $errors[] = 'File extension not allowed! Allowed extensions: '.implode(',', $allowedExt);
    }

    if($fileSize > $allowedMaxSize) {
      $errors[] = 'Maximum size exceeded! Size should be less than '.$allowedMaxSize.' bytes';
    }

    if(empty($errors)) {
      $targetFile = $uploadDir.$uniqueFileId.'.'.$fileExt;
      if(!move_uploaded_file($fileTmpName, $targetFile)) {
        $errors[] = 'Error uploading the file';
      }
    }

    return $errors;
  }
?>