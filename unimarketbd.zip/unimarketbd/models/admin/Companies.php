<?php
  class Companies {
    // DB stuff
    private $conn;
    private $tableName = 'companies';

    // Companies Properties
    public $id;
    public $name;
    public $location;
    public $description;
    public $createdAt;
    public $lastUpdated;

    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read All
    public function read() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName`;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Id
    public function readById() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read By Page
    public function readByPage() {
      $startRow = ($this->p - 1) * $this->rowsPerPage;
      $rowsPerPage = $this->rowsPerPage;

      // Create Query
      $query = "SELECT * FROM `$this->tableName` ORDER BY `createdAt` DESC LIMIT $startRow, $rowsPerPage;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create 
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`name`, `location`, `description`) VALUES(:name, :location, :description);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':name', $this->name);
      $stmt->bindParam(':location', $this->location);
      $stmt->bindParam(':description', $this->description);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Delete 
    public function delete() {
      // Create Query
      $query = "DELETE FROM `$this->tableName` WHERE `id` = :id;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':id', $this->id);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>