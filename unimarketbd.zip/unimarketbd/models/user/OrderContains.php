<?php
  class OrderContains {
    // DB stuff
    private $conn;
    private $tableName = 'order_contains';

    // Order Contains Properties
    public $orderId;
    public $productId;
    public $productName;
    public $productCategoryName;
    public $productCompanyName;
    public $productUnitPrice;
    public $productShippingCost;
    public $productQuantity;
    public $productDescription;

    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read total cost of the order
    public function readTotalCost() {
      // Create Query
      $query = "SELECT SUM((`productUnitPrice` * `productQuantity`) + `productShippingCost`) AS `totalCost` FROM `$this->tableName` WHERE `orderId` = :orderId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }
    
    // Read by Order Id
    public function readByOrderId() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `orderId` = :orderId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`orderId`, `productId`, `productName`, `productCategoryName`, `productCompanyName`, `productUnitPrice`, `productShippingCost`, `productQuantity`, `productDescription`) VALUES(:orderId, :productId, :productName, :productCategoryName, :productCompanyName, :productUnitPrice, :productShippingCost, :productQuantity, :productDescription);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);
      $stmt->bindParam(':productId', $this->productId);
      $stmt->bindParam(':productName', $this->productName);
      $stmt->bindParam(':productCategoryName', $this->productCategoryName);
      $stmt->bindParam(':productCompanyName', $this->productCompanyName);
      $stmt->bindParam(':productUnitPrice', $this->productUnitPrice);
      $stmt->bindParam(':productShippingCost', $this->productShippingCost);
      $stmt->bindParam(':productQuantity', $this->productQuantity);
      $stmt->bindParam(':productDescription', $this->productDescription);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>