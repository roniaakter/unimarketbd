<?php
  class Cart {
    // DB stuff
    private $conn;
    private $tableName = 'cart';

    // Cart Properties
    public $orderId;
    public $productId;
    public $quantity;

    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read Single
    public function readSingle() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `orderId` = :orderId AND `productId` = :productId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);
      $stmt->bindParam(':productId', $this->productId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read by Order Id
    public function readByOrderId() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `orderId` = :orderId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read by Order Id with Products
    public function readByOrderIdWithProducts() {
      // Create Query
      $query = "SELECT `p`.`id`, `p`.`name`, `p`.`stockUnits`, `cat`.`name` AS `categoryName`, `com`.`name` AS `companyName`, `p`.`unitPrice`, `p`.`shippingCost`, `c`.`quantity`, ((`p`.`unitPrice` * `c`.`quantity`) + `p`.`shippingCost`) AS `individualCost`, `p`.`description` FROM `$this->tableName` `c`, `products` `p`, `categories` `cat`, `companies` `com` WHERE `c`.`orderId` = :orderId AND `c`.`productId` = `p`.`id` AND `p`.`categoryId` = `cat`.`id` AND `p`.`companyId` = `com`.`id`;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read Single
    public function readTotalCost() {
      // Create Query
      $query = "SELECT SUM((`p`.`unitPrice` * `c`.`quantity`) + `p`.`shippingCost`) AS `totalCost` FROM `$this->tableName` `c`, `products` `p` WHERE `c`.`orderId` = :orderId AND `c`.`productId` = `p`.`id`;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read Total Cart Items
    public function readTotalCartItems() {
      // Create Query
      $query = "SELECT SUM(`quantity`) AS `totalItems` FROM `$this->tableName` WHERE `orderId` = :orderId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`orderId`, `productId`) VALUES(:orderId, :productId);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);
      $stmt->bindParam(':productId', $this->productId);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Update
    public function update() {
      // Create Query
      $query = "UPDATE `$this->tableName` SET `quantity` = :quantity WHERE `orderId` = :orderId AND `productId` = :productId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':quantity', $this->quantity);
      $stmt->bindParam(':orderId', $this->orderId);
      $stmt->bindParam(':productId', $this->productId);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Delete
    public function delete() {
      // Create Query
      $query = "DELETE FROM `$this->tableName` WHERE `orderId` = :orderId AND `productId` = :productId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);
      $stmt->bindParam(':productId', $this->productId);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>