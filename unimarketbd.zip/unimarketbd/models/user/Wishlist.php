<?php
  class Wishlist {
    // DB stuff
    private $conn;
    private $tableName = 'wishlist';

    // Wishlist Properties
    public $productId;
    public $userId;
    public $addedAt;

    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read single
    public function readSingle() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `productId` = :productId AND `userId` = :userId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':productId', $this->productId);
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read by userId
    public function readByUserId() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` WHERE `userId` = :userId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read by userId with products
    public function readByUserIdWithProducts() {
      // Create Query
      $query = "SELECT `p`.`id`, `p`.`name`, `p`.`unitPrice`, `p`.`shippingCost` FROM `$this->tableName` `w`, `products` `p` WHERE `w`.`productId` = `p`.`id` AND `w`.`userId` = :userId ORDER BY `w`.`addedAt` DESC;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`productId`, `userId`) VALUES(:productId, :userId);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':productId', $this->productId);
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }

    // Delete
    public function delete() {
      // Create Query
      $query = "DELETE FROM `$this->tableName` WHERE `productId` = :productId AND `userId` = :userId;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':productId', $this->productId);
      $stmt->bindParam(':userId', $this->userId);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>