<?php
  class OrderStatusesHistory {
    // DB stuff
    private $conn;
    private $tableName = 'order_statuses_history';

    // Order Statuses History Properties
    public $orderId;
    public $status;
    public $changedAt;

    public $userId;

    public $p;
    public $rowsPerPage;

    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Read order statuses history except instantiated ones
    public function readByOrderIdExceptInstantiated() {
      // Create Query
      $query = "SELECT * FROM `$this->tableName` `osh` WHERE `osh`.`orderId` = :orderId AND `osh`.`status` != 'Instantiated' ORDER BY `osh`.`changedAt` DESC;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read last "instantiated" order
    public function readLast() {
      // Create Query
      $query = "SELECT `o`.`id` FROM `$this->tableName` `osh`, `orders` `o` WHERE `o`.`userId` = :userId AND `osh`.`status` = :status AND `o`.`id` = `osh`.`orderId` ORDER BY `osh`.`changedAt` DESC LIMIT 1;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':userId', $this->userId);
      $stmt->bindParam(':status', $this->status);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read last "instantiated" order
    public function readLastByOrderId() {
      // Create Query
      $query = "SELECT `osh`.`status` FROM `$this->tableName` `osh` WHERE `osh`.`orderId` = :orderId ORDER BY `osh`.`changedAt` DESC LIMIT 1;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Read by page
    public function readByPage() {
      $startRow = ($this->p - 1) * $this->rowsPerPage;
      $rowsPerPage = $this->rowsPerPage;

      // Create Query
      $query = "SELECT * FROM `$this->tableName` `osh` WHERE `osh`.`status` = 'Pending' ORDER BY `osh`.`changedAt` DESC LIMIT $startRow, $rowsPerPage;";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    // Create 
    public function create() {
      // Create Query
      $query = "INSERT INTO `$this->tableName`(`orderId`, `status`) VALUES(:orderId, :status);";

      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Bind Param
      $stmt->bindParam(':orderId', $this->orderId);
      $stmt->bindParam(':status', $this->status);

      // Execute query
      if($stmt->execute()) {
        return true;
      }

      return false;
    }
  }
?>